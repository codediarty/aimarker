AIMarker 브랜드 키트 (2026.10)

로고 파일
- aimarker-logo: 가로형(기본)
- aimarker-logo-vertical: 세로형
- aimarker-symbol: 지문 심볼
- aimarker-wordmark: 글자만
- 색: (없음) 기본 / -dark 어두운 바탕 / -navy 네이비 한 색 / -white 흰색 한 색
- aimarker-symbol-small.svg: 24px보다 작게 쓸 때(파비콘 등)

색
- 네이비(Marker) #0E1F47  RGB 14 31 71
- 지문 블루(AI)  #0B63F6  RGB 11 99 246
- 지문 그라데이션 #0030C4 → #0858F0 → #0E8BFB → #33C8FF (왼쪽 아래 → 오른쪽 위)

글꼴: Pretendard (워드마크는 Pretendard 750을 다듬은 글자 윤곽)

사용 원칙
- 로고 둘레에는 'A' 높이만큼 여백을 둡니다.
- 가로형은 높이 20px, 심볼은 24px보다 작게 쓰지 않습니다. 그보다 작은 자리(파비콘 등)에는 단순형 심볼(aimarker-symbol-small.svg)을 씁니다.
- 늘이거나 기울이거나 색을 바꾸지 않습니다. AI와 Marker의 색을 서로 바꾸지 않습니다.
- 이 로고는 AIMarker를 소개하는 표시입니다. 콘텐츠에 붙이는 AI 표시가 아니며, 인증이나 보증 표시로 쓰지 않습니다.
  콘텐츠의 AI 표시는 https://aimarker.kr/mark/ 에서 근거에 맞게 발급하는 서명된 마크를 사용하세요.

자세한 안내: https://aimarker.kr/brand/
문의: contact@skkc.co.kr
